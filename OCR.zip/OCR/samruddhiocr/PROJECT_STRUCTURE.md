# SamruddhiOCR Project Structure

## Overview

SamruddhiOCR is a lightweight, English-only OCR library extracted and refactored from EasyOCR. It contains only the essential components needed for English text detection and recognition.

## Directory Structure

```
samruddhiocr/
├── __init__.py                 # Main package entry point
├── README.md                   # Documentation
├── PROJECT_STRUCTURE.md        # This file
│
├── detection/                  # Text detection module (CRAFT)
│   ├── __init__.py
│   ├── sam_craft.py           # CRAFT model definition
│   ├── sam_craft_utils.py     # Post-processing utilities
│   ├── sam_imgproc.py         # Image preprocessing
│   └── sam_detection.py       # Detection pipeline
│
├── recognition/                # Text recognition module (CRNN)
│   ├── __init__.py
│   ├── sam_resnet.py          # ResNet/VGG feature extractors
│   ├── sam_recognition.py     # Recognition model (Generation 2)
│   ├── sam_recog_utils.py     # Recognition utilities
│   └── sam_ctc_converter.py   # CTC decoding
│
├── core/                       # Core OCR pipeline
│   ├── __init__.py
│   ├── sam_reader.py          # Main SamruddhiReader class
│   └── sam_utils.py           # Core utilities
│
└── weights/                    # Model weights directory (placeholder)
    ├── craft.pth              # CRAFT detection weights
    └── recognition.pth        # Recognition model weights
```

## Key Components

### Detection Module
- **sam_craft.py**: CRAFT (Character Region Awareness for Text detection) model
- **sam_craft_utils.py**: Post-processing to extract bounding boxes from CRAFT output
- **sam_imgproc.py**: Image preprocessing (resize, normalize) for detection
- **sam_detection.py**: High-level detection pipeline

### Recognition Module
- **sam_resnet.py**: Feature extractors (VGG16_bn for CRAFT, VGG/ResNet for recognition)
- **sam_recognition.py**: CRNN recognition model (Generation 2 VGG-based for English)
- **sam_recog_utils.py**: Recognition pipeline and utilities
- **sam_ctc_converter.py**: CTC label converter for decoding predictions

### Core Module
- **sam_reader.py**: Main `SamruddhiReader` class that orchestrates detection and recognition
- **sam_utils.py**: Utility functions for image processing, box grouping, etc.

## What Was Removed

Compared to EasyOCR, the following were removed:
- All non-English language support (character sets, dictionaries, models)
- Training scripts and utilities
- CLI tools
- Unit tests
- Example notebooks
- Multi-language configuration files
- DBNet detection (kept only CRAFT)
- Generation 1 models (kept only Generation 2 for English)
- Complex language-specific decoding logic
- Dictionary-based word correction
- Paragraph grouping for RTL languages

## What Was Kept

- CRAFT text detection model
- Generation 2 VGG-based recognition model (optimized for English)
- Core image preprocessing
- CTC decoding (simplified for English)
- Basic text box grouping
- Essential utilities for image handling

## Character Set

English-only character set:
- Uppercase: A-Z
- Lowercase: a-z
- Digits: 0-9
- Symbols: !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~ €

## Model Files Required

1. **CRAFT Detection Model**: `craft_mlt_25k.pth`
   - URL: https://github.com/JaidedAI/EasyOCR/releases/download/pre-v1.1.6/craft_mlt_25k.zip
   - MD5: 2f8227d2def4037cdb3b34389dcf9ec1

2. **English Recognition Model**: `english_g2.pth`
   - URL: https://github.com/JaidedAI/EasyOCR/releases/download/v1.3/english_g2.zip
   - MD5: 5864788e1821be9e454ec108d61b887d

## Usage

```python
from samruddhiocr import SamruddhiReader

reader = SamruddhiReader()
result = reader.readtext("image.png")
```

## Dependencies

- torch
- torchvision
- opencv-python
- numpy
- pillow
- scikit-image

