"""
SamruddhiOCR Core Module
"""

from .sam_reader import SamruddhiReader

__all__ = ['SamruddhiReader']

