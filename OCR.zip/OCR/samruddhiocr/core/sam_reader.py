"""
SamruddhiOCR - Main Reader Class
English-only OCR library based on EasyOCR
"""

import torch
import numpy as np
import cv2
import os
from pathlib import Path
from logging import getLogger

from ..detection import sam_get_detector, sam_get_textbox
from ..recognition import sam_get_recognizer, sam_get_text
from .sam_utils import group_text_box, get_image_list, reformat_input, diff

LOGGER = getLogger(__name__)

# English-only character set: A-Z, a-z, 0-9, and common symbols
ENGLISH_CHARACTERS = "0123456789!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~ €ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"

# Model configuration for English (Generation 2)
IMG_HEIGHT = 64
RECOGNITION_NETWORK_PARAMS = {
    'input_channel': 1,
    'output_channel': 256,
    'hidden_size': 256
}


class SamruddhiReader(object):
    """Main OCR reader class for English text"""

    def __init__(self, gpu=True, model_storage_directory=None, 
                 download_enabled=True, detector=True, recognizer=True, 
                 verbose=True, quantize=True, cudnn_benchmark=False):
        """
        Create a SamruddhiOCR Reader for English text
        
        Parameters:
            gpu (bool): Enable GPU support (default: True)
            model_storage_directory (string): Path to directory for model data.
                If not specified, models will be stored in ~/.SamruddhiOCR/model/
            download_enabled (bool): Enable downloading of model data via HTTP (default: True)
            detector (bool): Load detection model (default: True)
            recognizer (bool): Load recognition model (default: True)
            verbose (bool): Print progress messages (default: True)
            quantize (bool): Quantize models for CPU (default: True)
            cudnn_benchmark (bool): Enable cuDNN benchmark (default: False)
        """
        self.verbose = verbose
        self.download_enabled = download_enabled
        self.character = ENGLISH_CHARACTERS

        # Set model storage directory
        if model_storage_directory:
            self.model_storage_directory = model_storage_directory
        else:
            self.model_storage_directory = os.path.expanduser("~/.SamruddhiOCR/model/")
        Path(self.model_storage_directory).mkdir(parents=True, exist_ok=True)

        # Set device
        if gpu is False:
            self.device = 'cpu'
            if verbose:
                LOGGER.warning('Using CPU. Note: This module is much faster with a GPU.')
        elif gpu is True:
            if torch.cuda.is_available():
                self.device = 'cuda'
            elif torch.backends.mps.is_available():
                self.device = 'mps'
            else:
                self.device = 'cpu'
                if verbose:
                    LOGGER.warning('Neither CUDA nor MPS are available - defaulting to CPU.')
        else:
            self.device = gpu

        self.quantize = quantize
        self.cudnn_benchmark = cudnn_benchmark

        # Detection model configuration
        self.detection_model = {
            'filename': 'craft_mlt_25k.pth',
            'url': 'https://github.com/JaidedAI/EasyOCR/releases/download/pre-v1.1.6/craft_mlt_25k.zip',
            'md5sum': '2f8227d2def4037cdb3b34389dcf9ec1'
        }

        # Recognition model configuration (English Generation 2)
        self.recognition_model = {
            'filename': 'english_g2.pth',
            'url': 'https://github.com/JaidedAI/EasyOCR/releases/download/v1.3/english_g2.zip',
            'md5sum': '5864788e1821be9e454ec108d61b887d'
        }

        # Load models
        if detector:
            detector_path = self._get_detector_path()
            self.detector = self._init_detector(detector_path)
        else:
            self.detector = None

        if recognizer:
            recognizer_path = self._get_recognizer_path()
            self.recognizer, self.converter = sam_get_recognizer(
                self.character, recognizer_path, device=self.device, quantize=quantize)
        else:
            self.recognizer = None
            self.converter = None

    def _get_detector_path(self):
        """Get path to detection model, download if needed"""
        detector_path = os.path.join(self.model_storage_directory, self.detection_model['filename'])
        
        if not os.path.isfile(detector_path):
            if not self.download_enabled:
                raise FileNotFoundError(f"Missing {detector_path} and downloads disabled")
            if self.verbose:
                LOGGER.warning('Downloading detection model, please wait...')
            # Note: In a real implementation, you would download and extract here
            # For now, we assume the model file exists or will be provided by user
        
        return detector_path

    def _get_recognizer_path(self):
        """Get path to recognition model, download if needed"""
        recognizer_path = os.path.join(self.model_storage_directory, self.recognition_model['filename'])
        
        if not os.path.isfile(recognizer_path):
            if not self.download_enabled:
                raise FileNotFoundError(f"Missing {recognizer_path} and downloads disabled")
            if self.verbose:
                LOGGER.warning('Downloading recognition model, please wait...')
            # Note: In a real implementation, you would download and extract here
        
        return recognizer_path

    def _init_detector(self, detector_path):
        """Initialize detector model"""
        return sam_get_detector(detector_path, 
                               device=self.device, 
                               quantize=self.quantize, 
                               cudnn_benchmark=self.cudnn_benchmark)

    def detect(self, img, min_size=20, text_threshold=0.7, low_text=0.4,
               link_threshold=0.4, canvas_size=2560, mag_ratio=1.,
               slope_ths=0.1, ycenter_ths=0.5, height_ths=0.5,
               width_ths=0.5, add_margin=0.1, reformat=True):
        """
        Detect text regions in image
        
        Returns:
            horizontal_list: List of horizontal text boxes
            free_list: List of free-form text boxes
        """
        if reformat:
            img, img_cv_grey = reformat_input(img)

        text_box_list = sam_get_textbox(self.detector, 
                                    img, 
                                    canvas_size=canvas_size, 
                                    mag_ratio=mag_ratio,
                                    text_threshold=text_threshold, 
                                    link_threshold=link_threshold, 
                                    low_text=low_text,
                                    poly=False, 
                                    device=self.device)

        horizontal_list_agg, free_list_agg = [], []
        for text_box in text_box_list:
            horizontal_list, free_list = group_text_box(text_box, slope_ths,
                                                        ycenter_ths, height_ths,
                                                        width_ths, add_margin)
            if min_size:
                horizontal_list = [i for i in horizontal_list if max(
                    i[1] - i[0], i[3] - i[2]) > min_size]
                free_list = [i for i in free_list if max(
                    diff([c[0] for c in i]), diff([c[1] for c in i])) > min_size]
            horizontal_list_agg.append(horizontal_list)
            free_list_agg.append(free_list)

        return horizontal_list_agg, free_list_agg

    def recognize(self, img_cv_grey, horizontal_list=None, free_list=None,
                  decoder='greedy', beamWidth=5, batch_size=1,
                  workers=0, allowlist=None, blocklist=None, detail=1,
                  contrast_ths=0.1, adjust_contrast=0.5, filter_ths=0.003,
                  reformat=True):
        """
        Recognize text in detected regions
        
        Returns:
            List of (box, text, confidence) tuples
        """
        if reformat:
            img, img_cv_grey = reformat_input(img_cv_grey)

        if allowlist:
            ignore_char = ''.join(set(self.character) - set(allowlist))
        elif blocklist:
            ignore_char = ''.join(set(blocklist))
        else:
            ignore_char = ''

        if (horizontal_list is None) and (free_list is None):
            y_max, x_max = img_cv_grey.shape
            horizontal_list = [[0, x_max, 0, y_max]]
            free_list = []

        # Process image regions
        if (batch_size == 1) or (self.device == 'cpu'):
            result = []
            for bbox in horizontal_list:
                h_list = [bbox]
                f_list = []
                image_list, max_width = get_image_list(h_list, f_list, img_cv_grey, model_height=IMG_HEIGHT)
                result0 = sam_get_text(self.character, IMG_HEIGHT, int(max_width), 
                                     self.recognizer, self.converter, image_list,
                                     ignore_char, decoder, beamWidth, batch_size, 
                                     contrast_ths, adjust_contrast, filter_ths,
                                     workers, self.device)
                result += result0
            for bbox in free_list:
                h_list = []
                f_list = [bbox]
                image_list, max_width = get_image_list(h_list, f_list, img_cv_grey, model_height=IMG_HEIGHT)
                result0 = sam_get_text(self.character, IMG_HEIGHT, int(max_width), 
                                     self.recognizer, self.converter, image_list,
                                     ignore_char, decoder, beamWidth, batch_size, 
                                     contrast_ths, adjust_contrast, filter_ths,
                                     workers, self.device)
                result += result0
        else:
            image_list, max_width = get_image_list(horizontal_list, free_list, img_cv_grey, model_height=IMG_HEIGHT)
            result = sam_get_text(self.character, IMG_HEIGHT, int(max_width), 
                                self.recognizer, self.converter, image_list,
                                ignore_char, decoder, beamWidth, batch_size, 
                                contrast_ths, adjust_contrast, filter_ths,
                                workers, self.device)

        if detail == 0:
            return [item[1] for item in result]
        else:
            return result

    def readtext(self, image, decoder='greedy', beamWidth=5, batch_size=1,
                 workers=0, allowlist=None, blocklist=None, detail=1,
                 min_size=20, contrast_ths=0.1, adjust_contrast=0.5, filter_ths=0.003,
                 text_threshold=0.7, low_text=0.4, link_threshold=0.4,
                 canvas_size=2560, mag_ratio=1.,
                 slope_ths=0.1, ycenter_ths=0.5, height_ths=0.5,
                 width_ths=0.5, add_margin=0.1):
        """
        Main method to read text from image
        
        Parameters:
            image: file path, numpy array, or bytes
            detail: 0 for text only, 1 for (box, text, confidence)
        
        Returns:
            List of detected text with bounding boxes and confidence scores
        """
        img, img_cv_grey = reformat_input(image)

        horizontal_list, free_list = self.detect(img, 
                                                 min_size=min_size, 
                                                 text_threshold=text_threshold,
                                                 low_text=low_text, 
                                                 link_threshold=link_threshold,
                                                 canvas_size=canvas_size, 
                                                 mag_ratio=mag_ratio,
                                                 slope_ths=slope_ths, 
                                                 ycenter_ths=ycenter_ths,
                                                 height_ths=height_ths, 
                                                 width_ths=width_ths,
                                                 add_margin=add_margin, 
                                                 reformat=False)

        # Get the first result from hor & free list
        horizontal_list, free_list = horizontal_list[0], free_list[0]
        
        result = self.recognize(img_cv_grey, horizontal_list, free_list,
                                decoder, beamWidth, batch_size,
                                workers, allowlist, blocklist, detail,
                                contrast_ths, adjust_contrast,
                                filter_ths, False)

        return result

