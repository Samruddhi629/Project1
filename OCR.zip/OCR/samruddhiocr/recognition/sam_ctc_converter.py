"""
SamruddhiOCR - CTC Label Converter
Based on EasyOCR's utils.py CTCLabelConverter (simplified for English only)
"""

import torch
import numpy as np


def consecutive(data, mode ='first', stepsize=1):
    """Find consecutive sequences"""
    group = np.split(data, np.where(np.diff(data) != stepsize)[0]+1)
    group = [item for item in group if len(item)>0]

    if mode == 'first': result = [l[0] for l in group]
    elif mode == 'last': result = [l[-1] for l in group]
    return result


def simplify_label(labeling, blankIdx = 0):
    """Simplify CTC label by removing blanks and duplicates"""
    labeling = np.array(labeling)

    # collapse blank
    idx = np.where(~((np.roll(labeling,1) == labeling) & (labeling == blankIdx)))[0]
    labeling = labeling[idx]

    # get rid of blank between different characters
    idx = np.where( ~((np.roll(labeling,1) != np.roll(labeling,-1)) & (labeling == blankIdx)) )[0]

    if len(labeling) > 0:
        last_idx = len(labeling)-1
        if last_idx not in idx: idx = np.append(idx, [last_idx])
    labeling = labeling[idx]

    return tuple(labeling)


def ctcBeamSearch(mat, classes, ignore_idx, lm, beamWidth=25, dict_list = []):
    """CTC Beam Search decoder (simplified version)"""
    blankIdx = 0
    maxT, maxC = mat.shape

    # Simple greedy decoding for English-only
    bestLabeling = []
    for t in range(maxT):
        best_idx = np.argmax(mat[t, :])
        if best_idx not in ignore_idx:
            if len(bestLabeling) == 0 or bestLabeling[-1] != best_idx:
                bestLabeling.append(best_idx)
    
    res = ''
    for i, l in enumerate(bestLabeling):
        if l not in ignore_idx and (not (i > 0 and bestLabeling[i - 1] == l)):
            res += classes[l]
    return res


class CTCLabelConverter(object):
    """ Convert between text-label and text-index for English only"""

    def __init__(self, character):
        # character (str): set of the possible characters (English A-Z, a-z, 0-9, symbols)
        dict_character = list(character)

        self.dict = {}
        for i, char in enumerate(dict_character):
            self.dict[char] = i + 1

        self.character = ['[blank]'] + dict_character  # dummy '[blank]' token for CTCLoss (index 0)
        self.ignore_idx = [0]  # Only blank token to ignore

    def encode(self, text, batch_max_length=25):
        """convert text-label into text-index."""
        length = [len(s) for s in text]
        text = ''.join(text)
        text = [self.dict[char] for char in text]
        return (torch.IntTensor(text), torch.IntTensor(length))

    def decode_greedy(self, text_index, length):
        """ convert text-index into text-label using greedy decoding."""
        texts = []
        index = 0
        for l in length:
            t = text_index[index:index + l]
            # Returns a boolean array where true is when the value is not repeated
            a = np.insert(~((t[1:]==t[:-1])),0,True)
            # Returns a boolean array where true is when the value is not in the ignore_idx list
            b = ~np.isin(t,np.array(self.ignore_idx))
            # Combine the two boolean array
            c = a & b
            # Gets the corresponding character according to the saved indexes
            text = ''.join(np.array(self.character)[t[c.nonzero()]])
            texts.append(text)
            index += l
        return texts

    def decode_beamsearch(self, mat, beamWidth=5):
        """Decode using beam search"""
        texts = []
        for i in range(mat.shape[0]):
            t = ctcBeamSearch(mat[i], self.character, self.ignore_idx, None, beamWidth=beamWidth)
            texts.append(t)
        return texts

