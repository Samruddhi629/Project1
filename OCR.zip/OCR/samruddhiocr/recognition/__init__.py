"""
SamruddhiOCR Recognition Module
"""

from .sam_recog_utils import sam_get_recognizer, sam_get_text
from .sam_recognition import SamruddhiRecognitionModel

__all__ = ['sam_get_recognizer', 'sam_get_text', 'SamruddhiRecognitionModel']
