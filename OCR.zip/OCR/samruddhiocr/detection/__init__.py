"""
SamruddhiOCR Detection Module
"""

from .sam_detection import sam_get_detector, sam_get_textbox
from .sam_craft import CRAFT

__all__ = ['sam_get_detector', 'sam_get_textbox', 'CRAFT']
