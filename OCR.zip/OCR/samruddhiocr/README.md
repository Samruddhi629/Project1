# SamruddhiOCR

A lightweight, English-only OCR library based on EasyOCR's core architecture.

## Features

- **English-only**: Optimized for English text (A-Z, a-z, 0-9, and common symbols)
- **Lightweight**: Minimal codebase with only essential components
- **CRAFT Detection**: Uses CRAFT model for accurate text detection
- **CRNN Recognition**: Uses Generation 2 VGG-based recognition model
- **Simple API**: Clean and easy-to-use interface

## Installation

```bash
pip install torch torchvision
pip install opencv-python
pip install scikit-image
pip install numpy pillow
```

## Quick Start

```python
from samruddhiocr import SamruddhiReader

# Initialize reader
reader = SamruddhiReader()

# Read text from image
result = reader.readtext("image.png")

# Print results
for (bbox, text, confidence) in result:
    print(f"{text} (confidence: {confidence:.2f})")
```

## API

### SamruddhiReader

Main class for OCR operations.

#### Initialization

```python
reader = SamruddhiReader(
    gpu=True,                    # Use GPU if available
    model_storage_directory=None, # Custom model directory
    download_enabled=True,       # Auto-download models
    detector=True,              # Load detection model
    recognizer=True,            # Load recognition model
    verbose=True,               # Print progress
    quantize=True,              # Quantize for CPU
    cudnn_benchmark=False       # Enable cuDNN benchmark
)
```

#### Methods

##### `readtext(image, ...)`

Main method to extract text from an image.

**Parameters:**
- `image`: File path, numpy array, or bytes
- `detail`: 0 for text only, 1 for (box, text, confidence)
- `decoder`: 'greedy' or 'beamsearch'
- `batch_size`: Batch size for processing
- `text_threshold`: Text detection threshold (default: 0.7)
- `link_threshold`: Link detection threshold (default: 0.4)
- `low_text`: Low text threshold (default: 0.4)

**Returns:**
- If `detail=0`: List of text strings
- If `detail=1`: List of (bbox, text, confidence) tuples

##### `detect(image, ...)`

Detect text regions without recognition.

**Returns:** `(horizontal_list, free_list)` - Lists of bounding boxes

##### `recognize(image, horizontal_list, free_list, ...)`

Recognize text in detected regions.

**Returns:** List of (box, text, confidence) tuples

## Model Files

The library requires two model files:
1. **CRAFT detection model**: `craft_mlt_25k.pth`
2. **English recognition model**: `english_g2.pth`

Models are automatically downloaded to `~/.SamruddhiOCR/model/` on first use, or you can manually place them in a custom directory.

## Character Set

SamruddhiOCR supports:
- Uppercase letters: A-Z
- Lowercase letters: a-z
- Digits: 0-9
- Common symbols: !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~ €

## License

Based on EasyOCR (MIT License). See original EasyOCR repository for details.

## Differences from EasyOCR

- **English-only**: Removed all multi-language support
- **Simplified**: Removed training scripts, CLI tools, and non-essential utilities
- **Focused**: Only includes detection and recognition components
- **Clean API**: Simplified interface with English-specific optimizations

