"""
SamruddhiOCR - Lightweight English-only OCR Library
Based on EasyOCR, optimized for English text recognition
"""

from .core import SamruddhiReader

__version__ = '1.0.0'

__all__ = ['SamruddhiReader']

