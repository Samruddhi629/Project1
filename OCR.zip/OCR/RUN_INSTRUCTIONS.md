# How to Run SamruddhiOCR and Test with Sample Images

## Step 1: Install Dependencies

```bash
pip install torch torchvision
pip install opencv-python
pip install scikit-image
pip install numpy pillow
```

## Step 2: Download Model Files

You have two options:

### Option A: Automatic Download (Recommended)

Run the download script:

```bash
python download_models.py
```

This will automatically download and verify:
- CRAFT detection model (`craft_mlt_25k.pth`)
- English recognition model (`english_g2.pth`)

Models will be saved to: `~/.SamruddhiOCR/model/`

### Option B: Manual Download

1. Download CRAFT model:
   - URL: https://github.com/JaidedAI/EasyOCR/releases/download/pre-v1.1.6/craft_mlt_25k.zip
   - Extract `craft_mlt_25k.pth` to `~/.SamruddhiOCR/model/`

2. Download English recognition model:
   - URL: https://github.com/JaidedAI/EasyOCR/releases/download/v1.3/english_g2.zip
   - Extract `english_g2.pth` to `~/.SamruddhiOCR/model/`

## Step 3: Test with Sample Image

### Quick Test (Creates Test Image Automatically)

```bash
python test_samruddhiocr.py
```

This will:
1. Create a test image with text "Hello World 123"
2. Run OCR on it
3. Display results and accuracy

### Test with Your Own Image

```bash
# Basic usage
python test_samruddhiocr.py path/to/your/image.png

# With expected text for accuracy calculation
python test_samruddhiocr.py path/to/your/image.png "Expected text here"
```

### Example Output

```
============================================================
Testing SamruddhiOCR on: test_image.png
============================================================

Initializing SamruddhiReader...
✓ Reader initialized successfully

Running OCR...
✓ OCR completed. Found 1 text regions

============================================================
OCR RESULTS:
============================================================

Region 1:
  Text: 'Hello World 123'
  Confidence: 0.9876
  Bounding Box: [[100, 50], [500, 50], [500, 150], [100, 150]]

============================================================
COMBINED TEXT:
============================================================
'Hello World 123'

============================================================
ACCURACY EVALUATION:
============================================================

Character-level accuracy: 100.00%
  Correct characters: 15/15
Word-level accuracy: 100.00%
  Correct words: 3/3
Exact match: ✓ YES

Expected: 'Hello World 123'
Detected: 'Hello World 123'
```

## Step 4: Use in Your Code

```python
from samruddhiocr import SamruddhiReader

# Initialize reader
reader = SamruddhiReader()

# Read text from image
results = reader.readtext("image.png", detail=1)

# Process results
for bbox, text, confidence in results:
    print(f"Text: {text}")
    print(f"Confidence: {confidence:.4f}")
    print(f"Bounding Box: {bbox}")
```

## Testing Accuracy

The test script calculates three types of accuracy:

1. **Character-level accuracy**: Percentage of correctly recognized characters
2. **Word-level accuracy**: Percentage of correctly recognized words
3. **Exact match**: Whether the entire text matches exactly

### Example with Accuracy Testing

```python
from samruddhiocr import SamruddhiReader

reader = SamruddhiReader()
results = reader.readtext("image.png", detail=1)

# Get all detected text
detected_text = " ".join([text for _, text, _ in results])

# Compare with expected
expected_text = "Hello World"
accuracy = calculate_accuracy(expected_text, detected_text)
```

## Troubleshooting

### Error: Model files not found

**Solution**: Run `python download_models.py` to download models

### Error: CUDA out of memory

**Solution**: Use CPU mode:
```python
reader = SamruddhiReader(gpu=False)
```

### Error: Import errors

**Solution**: Install missing dependencies:
```bash
pip install -r requirements.txt
```

### Low accuracy results

**Tips**:
- Use high-quality images (300+ DPI)
- Ensure good contrast between text and background
- Use images with clear, readable fonts
- Adjust detection thresholds if needed:
  ```python
  results = reader.readtext("image.png", 
                           text_threshold=0.7,  # Lower = more detections
                           link_threshold=0.4)  # Lower = more links
  ```

## Advanced Usage

### Adjust Detection Parameters

```python
results = reader.readtext("image.png",
    text_threshold=0.7,    # Text detection threshold
    link_threshold=0.4,   # Link detection threshold
    low_text=0.4,         # Low text threshold
    canvas_size=2560,     # Canvas size for detection
    mag_ratio=1.0         # Magnification ratio
)
```

### Adjust Recognition Parameters

```python
results = reader.readtext("image.png",
    decoder='greedy',     # or 'beamsearch'
    beamWidth=5,          # Beam width for beam search
    batch_size=1,         # Batch size
    contrast_ths=0.1,     # Contrast threshold
    adjust_contrast=0.5   # Contrast adjustment
)
```

### Get Only Text (No Bounding Boxes)

```python
results = reader.readtext("image.png", detail=0)
# Returns: ['Hello', 'World', '123']
```

## Performance Tips

1. **Use GPU**: Much faster on GPU (if available)
2. **Batch Processing**: Process multiple images in batch
3. **Image Preprocessing**: Preprocess images for better results
4. **Model Quantization**: Already enabled by default for CPU

## Example Test Images

You can test with:
- Screenshots of text
- Scanned documents
- Photos of text
- Handwritten text (may have lower accuracy)

For best results, use:
- Clear, printed text
- Good lighting
- High resolution
- Minimal background noise

