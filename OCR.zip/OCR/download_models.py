"""
Script to download required model files for SamruddhiOCR
"""

import os
import sys
import hashlib
import zipfile
from pathlib import Path
from urllib.request import urlretrieve

def calculate_md5(fname):
    """Calculate MD5 hash of a file"""
    hash_md5 = hashlib.md5()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def download_and_unzip(url, filename, model_storage_directory, md5sum=None, verbose=True):
    """Download and extract model file"""
    zip_path = os.path.join(model_storage_directory, 'temp.zip')
    model_path = os.path.join(model_storage_directory, filename)
    
    # Check if already exists
    if os.path.exists(model_path):
        if md5sum:
            if calculate_md5(model_path) == md5sum:
                if verbose:
                    print(f"✓ {filename} already exists and is valid")
                return model_path
            else:
                print(f"⚠ {filename} exists but MD5 mismatch. Re-downloading...")
                os.remove(model_path)
        else:
            if verbose:
                print(f"✓ {filename} already exists")
            return model_path
    
    # Download
    if verbose:
        print(f"Downloading {filename}...")
        print(f"URL: {url}")
    
    def progress_hook(count, blockSize, totalSize):
        progress = count * blockSize / totalSize
        percent = min(100, progress * 100)
        bar_length = 50
        filled = int(bar_length * progress)
        bar = '█' * filled + '-' * (bar_length - filled)
        print(f'\rProgress: |{bar}| {percent:.1f}%', end='', flush=True)
    
    try:
        urlretrieve(url, zip_path, reporthook=progress_hook)
        print()  # New line after progress
        
        # Extract
        if verbose:
            print(f"Extracting {filename}...")
        with zipfile.ZipFile(zip_path, 'r') as zipObj:
            zipObj.extract(filename, model_storage_directory)
        
        # Verify MD5
        if md5sum:
            if verbose:
                print(f"Verifying MD5 checksum...")
            actual_md5 = calculate_md5(model_path)
            if actual_md5 != md5sum:
                print(f"⚠ MD5 mismatch! Expected: {md5sum}, Got: {actual_md5}")
                print("File may be corrupted. You may need to re-download.")
            else:
                if verbose:
                    print(f"✓ MD5 checksum verified")
        
        # Clean up
        os.remove(zip_path)
        
        if verbose:
            print(f"✓ {filename} downloaded and extracted successfully")
        return model_path
        
    except Exception as e:
        print(f"\n✗ Error downloading {filename}: {e}")
        if os.path.exists(zip_path):
            os.remove(zip_path)
        return None


def main():
    """Download all required models"""
    print("="*60)
    print("SamruddhiOCR Model Downloader")
    print("="*60)
    
    # Model storage directory
    model_storage_directory = os.path.expanduser("~/.SamruddhiOCR/model/")
    Path(model_storage_directory).mkdir(parents=True, exist_ok=True)
    
    print(f"\nModel storage directory: {model_storage_directory}\n")
    
    # Detection model (CRAFT)
    print("1. Downloading CRAFT detection model...")
    craft_model = download_and_unzip(
        url='https://github.com/JaidedAI/EasyOCR/releases/download/pre-v1.1.6/craft_mlt_25k.zip',
        filename='craft_mlt_25k.pth',
        model_storage_directory=model_storage_directory,
        md5sum='2f8227d2def4037cdb3b34389dcf9ec1',
        verbose=True
    )
    
    print("\n" + "-"*60 + "\n")
    
    # Recognition model (English Generation 2)
    print("2. Downloading English recognition model...")
    english_model = download_and_unzip(
        url='https://github.com/JaidedAI/EasyOCR/releases/download/v1.3/english_g2.zip',
        filename='english_g2.pth',
        model_storage_directory=model_storage_directory,
        md5sum='5864788e1821be9e454ec108d61b887d',
        verbose=True
    )
    
    print("\n" + "="*60)
    print("Download Summary")
    print("="*60)
    
    if craft_model:
        print(f"✓ CRAFT model: {craft_model}")
    else:
        print("✗ CRAFT model: Failed to download")
    
    if english_model:
        print(f"✓ English model: {english_model}")
    else:
        print("✗ English model: Failed to download")
    
    if craft_model and english_model:
        print("\n✓ All models downloaded successfully!")
        print("\nYou can now use SamruddhiOCR:")
        print("  from samruddhiocr import SamruddhiReader")
        print("  reader = SamruddhiReader()")
    else:
        print("\n⚠ Some models failed to download. Please check your internet connection.")


if __name__ == "__main__":
    main()

