"""
Test script for SamruddhiOCR
Tests OCR on a sample image and displays results
"""

import os
import sys
import cv2
import numpy as np
from pathlib import Path

# Add samruddhiocr to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from samruddhiocr import SamruddhiReader


def test_ocr(image_path, expected_text=None):
    """
    Test OCR on an image
    
    Args:
        image_path: Path to image file
        expected_text: Optional expected text for accuracy calculation
    """
    print(f"\n{'='*60}")
    print(f"Testing SamruddhiOCR on: {image_path}")
    print(f"{'='*60}\n")
    
    # Check if image exists
    if not os.path.exists(image_path):
        print(f"ERROR: Image file not found: {image_path}")
        return
    
    # Initialize reader
    print("Initializing SamruddhiReader...")
    try:
        reader = SamruddhiReader(gpu=True, verbose=True)
        print("✓ Reader initialized successfully\n")
    except Exception as e:
        print(f"ERROR initializing reader: {e}")
        print("\nNote: Make sure model files are available:")
        print("  - craft_mlt_25k.pth (CRAFT detection model)")
        print("  - english_g2.pth (English recognition model)")
        print("\nModels should be in: ~/.SamruddhiOCR/model/")
        return
    
    # Read text from image
    print("Running OCR...")
    try:
        results = reader.readtext(image_path, detail=1)
        print(f"✓ OCR completed. Found {len(results)} text regions\n")
    except Exception as e:
        print(f"ERROR during OCR: {e}")
        import traceback
        traceback.print_exc()
        return
    
    # Display results
    print(f"{'='*60}")
    print("OCR RESULTS:")
    print(f"{'='*60}\n")
    
    all_detected_text = []
    for i, (bbox, text, confidence) in enumerate(results, 1):
        print(f"Region {i}:")
        print(f"  Text: '{text}'")
        print(f"  Confidence: {confidence:.4f}")
        print(f"  Bounding Box: {bbox}")
        print()
        all_detected_text.append(text)
    
    # Combine all text
    combined_text = " ".join(all_detected_text)
    print(f"{'='*60}")
    print(f"COMBINED TEXT:")
    print(f"{'='*60}")
    print(f"'{combined_text}'\n")
    
    # Calculate accuracy if expected text provided
    if expected_text:
        print(f"{'='*60}")
        print("ACCURACY EVALUATION:")
        print(f"{'='*60}\n")
        
        expected_clean = expected_text.lower().strip()
        detected_clean = combined_text.lower().strip()
        
        # Character-level accuracy
        expected_chars = list(expected_clean.replace(" ", ""))
        detected_chars = list(detected_clean.replace(" ", ""))
        
        if len(expected_chars) > 0:
            correct_chars = sum(1 for i, char in enumerate(expected_chars) 
                              if i < len(detected_chars) and detected_chars[i] == char)
            char_accuracy = (correct_chars / len(expected_chars)) * 100
            print(f"Character-level accuracy: {char_accuracy:.2f}%")
            print(f"  Correct characters: {correct_chars}/{len(expected_chars)}")
        
        # Word-level accuracy
        expected_words = expected_clean.split()
        detected_words = detected_clean.split()
        
        if len(expected_words) > 0:
            correct_words = sum(1 for word in expected_words if word in detected_words)
            word_accuracy = (correct_words / len(expected_words)) * 100
            print(f"Word-level accuracy: {word_accuracy:.2f}%")
            print(f"  Correct words: {correct_words}/{len(expected_words)}")
        
        # Exact match
        exact_match = (expected_clean == detected_clean)
        print(f"Exact match: {'✓ YES' if exact_match else '✗ NO'}")
        
        print(f"\nExpected: '{expected_text}'")
        print(f"Detected: '{combined_text}'")
    
    return results


def create_test_image():
    """Create a simple test image with text"""
    print("Creating test image...")
    
    # Create a white image
    img = np.ones((200, 600, 3), dtype=np.uint8) * 255
    
    # Add text using OpenCV
    font = cv2.FONT_HERSHEY_SIMPLEX
    text = "Hello World 123"
    font_scale = 1.5
    color = (0, 0, 0)
    thickness = 2
    
    # Get text size
    (text_width, text_height), baseline = cv2.getTextSize(text, font, font_scale, thickness)
    
    # Center the text
    x = (img.shape[1] - text_width) // 2
    y = (img.shape[0] + text_height) // 2
    
    cv2.putText(img, text, (x, y), font, font_scale, color, thickness)
    
    # Save image
    test_image_path = "test_image.png"
    cv2.imwrite(test_image_path, img)
    print(f"✓ Test image created: {test_image_path}")
    
    return test_image_path, text


if __name__ == "__main__":
    print("\n" + "="*60)
    print("SamruddhiOCR Test Script")
    print("="*60)
    
    # Check command line arguments
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
        expected_text = sys.argv[2] if len(sys.argv) > 2 else None
        test_ocr(image_path, expected_text)
    else:
        # Create and test with a sample image
        print("\nNo image provided. Creating a test image...")
        test_image_path, expected_text = create_test_image()
        print(f"\nExpected text: '{expected_text}'")
        
        # Test with the created image
        test_ocr(test_image_path, expected_text)
        
        print(f"\n{'='*60}")
        print("Usage:")
        print(f"{'='*60}")
        print("  python test_samruddhiocr.py <image_path> [expected_text]")
        print("\nExample:")
        print("  python test_samruddhiocr.py image.png 'Hello World'")
        print("  python test_samruddhiocr.py image.png")

